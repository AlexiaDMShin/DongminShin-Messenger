package com.example.mymessenger.ui.recruit

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel

class RecruitViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is recruit Fragment"
    }
    val text: LiveData<String> = _text
}