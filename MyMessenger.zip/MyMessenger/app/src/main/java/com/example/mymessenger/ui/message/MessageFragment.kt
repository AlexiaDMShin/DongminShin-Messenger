package com.example.mymessenger.ui.message

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
//import android.widget.TextView
import android.support.v4.app.Fragment
import android.arch.lifecycle.ViewModelProvider
import com.example.mymessenger.R
import com.example.mymessenger.databinding.FragmentMessageBinding

class MessageFragment : Fragment() {

    private var _binding: FragmentMessageBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    lateinit var MessageAdapter: MessageAdapter
    val datas = mutableListOf<MessageData>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val messageViewModel =
            ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
                MessageViewModel::class.java
            )

        _binding = FragmentMessageBinding.inflate(inflater, container, false)
        val root: View = binding.root

        initRecycler()

        /*val textView: TextView = binding.textMessage
        messageViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }*/
        return root
    }

    private fun initRecycler() {
        MessageAdapter = MessageAdapter(this)
        //rv_message.adapter = MessageAdapter


        datas.apply {
            add(MessageData(photo = R.drawable.ic_home_black_24dp, name = "조인성", msg_text = "안녕하세요."))
            add(MessageData(photo = R.drawable.ic_home_black_24dp, name = "정우성", msg_text = "반갑습니다."))
            add(MessageData(photo = R.drawable.ic_home_black_24dp, name = "조승우", msg_text = "조승우입니다."))
            add(MessageData(photo = R.drawable.ic_home_black_24dp, name = "고은성", msg_text = "무슨 문제가 있습니까?"))
            add(MessageData(photo = R.drawable.ic_home_black_24dp, name = "홍광호", msg_text = "연락주세요."))

            MessageAdapter.datas = datas
            MessageAdapter.notifyDataSetChanged()

        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}