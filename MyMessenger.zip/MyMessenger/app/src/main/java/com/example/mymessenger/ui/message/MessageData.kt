package com.example.mymessenger.ui.message

data class MessageData(
    val name : String,
    val msg_text : String,
    val photo : Int
)
